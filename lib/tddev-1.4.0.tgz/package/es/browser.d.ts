/** 浏览器枚举 */
export declare enum BrowerType {
    Ie = "Ie",
    Edge = "Edge",
    Firefox = "Firefox",
    Chrome = "Chrome",
    Safari = "Safari",
    Unknown = "Unknown"
}

/** 浏览器工具库 */
declare abstract class Browser {
    private constructor();
    /** 生成浏览器指纹 */
    static getBrowerId: () => Promise<string>;
    /** 获取浏览器信息 */
    static getBrowerInfo: () => {
        type: BrowerType;
        version: string;
        fullVersion: string;
    };
    /** 开启硬件加速 */
    static isOpenGPU: () => boolean;
}
export default Browser;

export { }
