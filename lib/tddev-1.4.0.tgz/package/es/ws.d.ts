import { Ref } from 'vue';

/** 创建 Socket 客户端 */
export declare const createWS: (url: string, options: WSOptions) => Promise<WSClient>;

/** Socket 客户端连接工具 hooks用法 */
export declare const useWSClient: (url: string, options: WSOptions) => Ref<WSClient | undefined, WSClient | undefined>;

/** Socket 客户端连接工具 */
declare class WSClient {
    static instance: WSClient | null;
    private client;
    private options;
    private eventStore;
    constructor(uri: string, options: WSOptions);
    /** 初始化 */
    private initClicent;
    /** 注册事件 */
    on: <T>(type: string, event: (data: T) => void, once?: boolean) => undefined;
    /** 取消事件注册 */
    off: (type: string, event: Function) => undefined;
    /** 清空某个类型的事件注册 */
    clear: (type: string) => undefined;
    /** 清空所有的事件注册 */
    clearAll: () => undefined;
    /** 销毁 */
    destory: () => undefined;
    /** 发送消息 */
    send: (type: string, message: any) => undefined;
}
export default WSClient;

export declare interface WSOptions {
    /** 认证auth信息 */
    token: string;
    /** 其他参数 */
    query?: Obj;
    /** 路径 */
    path?: string;
    /** 连接关闭回调 */
    close?: Function;
    /** 连接成功回调 */
    open?: (client: WSClient) => void;
    /** 连接错误回调 */
    error?: Function;
    /** 连接断开 */
    disconnect?: Function;
}

export { }
