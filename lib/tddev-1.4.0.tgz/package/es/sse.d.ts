import { Ref } from 'vue';

/** 创建 Sse客户端 */
export declare const createSSE: (url: string, options: SseOptions) => Promise<SSEClient>;

/** Sse 客户端连接工具 */
declare class SSEClient {
    static instance: SSEClient | null;
    private client;
    private options;
    private eventStore;
    constructor(uri: string, options: SseOptions);
    /** 初始化 */
    private initClicent;
    /** 注册事件 */
    on: <T>(type: string, event: (data: T) => void, once?: boolean) => undefined;
    /** 取消事件注册 */
    off: (type: string, event: Function) => undefined;
    /** 清空某个类型的事件注册 */
    clear: (type: string) => undefined;
    /** 清空所有的事件注册 */
    clearAll: () => undefined;
    /** 销毁 */
    destory: () => undefined;
}
export default SSEClient;

export declare interface SseOptions {
    /** 认证auth信息 */
    token: string;
    /** 信道ID */
    channelId?: string;
    /** 连接关闭回调 */
    close?: Function;
    /** 连接成功回调 */
    open?: (client: SSEClient) => void;
    /** 连接错误回调 */
    error?: Function;
}

/** Sse 客户端连接工具 hooks用法 */
export declare const useSSEClient: (url: string, options: SseOptions) => Ref<SSEClient | undefined, SSEClient | undefined>;

export { }
