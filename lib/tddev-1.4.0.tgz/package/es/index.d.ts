import { Dayjs } from 'dayjs';
import { default as default_2 } from 'dayjs';

/** 工具函数 */
export declare const _: {
    isDev: isDev;
    isTest: isTest;
    isProd: isProd;
    isAndroid: isAndroid;
    isIOS: isIOS;
    isHarmony: isHarmony;
    isObject: isObject;
    isEmptyObject: isEmptyObject;
    isNotEmptyObject: isNotEmptyObject;
    isFunction: isFunction;
    isSymbol: isSymbol;
    isBigInt: isBigInt;
    isNumber: isNumber;
    isUpInteger: isUpInteger;
    isBoolean: isBoolean;
    isString: isString;
    isNotEmptyString: isNotEmptyString;
    isArray: isArray;
    isEmptyArray: isEmptyArray;
    isNotEmptyArray: isNotEmptyArray;
    isExist: isExist;
    isNotExist: isNotExist;
    isEqual: isEqual;
    isDate: isDate;
    isDayjs: isDayjs;
    getEnv: getEnv;
    getUuid: getUuid;
    getArray: getArray;
    getArrayAt: getArrayAt;
    getArrayItem: getArrayItem;
    getArrayNotRepeat: getArrayNotRepeat;
    getMapWithArray: getMapWithArray;
    getMapWithObject: getMapWithObject;
    getObject: getObject;
    getObjectFilterKey: getObjectFilterKey;
    getObjectFilterEmptyAttr: getObjectFilterEmptyAttr;
    getFunction: getFunction;
    getBoolean: getBoolean;
    getBooleanLike: getBooleanLike;
    getString: getString;
    getStringAt: getStringAt;
    getNumber: getNumber;
    getNumberToFixed: getNumberToFixed;
    getNumbertoThousands: getNumbertoThousands;
    getComputedDiff: getComputedDiff;
    getWebWorker: getWebWorker;
    getDayjs: getDayjs;
    getDayNow: getDayNow;
    getCurrentTime: getCurrentTime;
    getSearchParam: getSearchParam;
    getJSONparse: getJSONparse;
    getSafeValue: getSafeValue;
    setAttr: setAttr;
    formatter: string;
    formatterTime: formatterTime;
    emptyFunc: emptyFunc;
    deepClone: deepClone;
    writeToClipboard: writeToClipboard;
    loadScript: loadScript;
    occurPromise: occurPromise;
};

/** 浏览器枚举 */
declare enum BrowerType {
    Ie = "Ie",
    Edge = "Edge",
    Firefox = "Firefox",
    Chrome = "Chrome",
    Safari = "Safari",
    Unknown = "Unknown"
}

/** 浏览器工具库 */
export declare const Browser: typeof browser;

/** 浏览器工具库 */
export declare abstract class browser {
    private constructor();
    /** 生成浏览器指纹 */
    static getBrowerId: () => Promise<string>;
    /** 获取浏览器信息 */
    static getBrowerInfo: () => {
        type: BrowerType;
        version: string;
        fullVersion: string;
    };
    /** 开启硬件加速 */
    static isOpenGPU: () => boolean;
}

/** 深拷贝 */
declare function deepClone<T>(obj: T, __clonedObjects__?: WeakMap<WeakKey, any>): T;

declare type DiffParam<T> = {
    /** 新数据 */
    newDataSource: T[];
    /** 旧数据 */
    oldDataSource: T[];
    options?: {
        /** 比对的主键-默认为id字段 */
        primaryKey?: string;
        /** 自定义比对函数-默认为全字段匹配 */
        isEqual?: (sourceOne: T, sourceTow: T) => boolean;
    };
};

declare type DiffReturn<T> = {
    /** 新增的项 */
    createItems: T[];
    /** 更新的项 */
    updateItems: T[];
    /** 被更新的项 */
    updatedItems: T[];
    /** 删除的项 */
    deleteItems: T[];
    /** 新增的id */
    createIds: Id[];
    /** 更新的id */
    updateIds: Id[];
    /** 删除的id */
    deleteIds: Id[];
};

/** 空方法 */
declare function emptyFunc(): void;

/** 加解密工具 */
export declare const Encrypt: typeof encrypt;

/** 加解密工具 */
export declare abstract class encrypt {
    private constructor();
    /** atob */
    static atob: (asc: string) => string;
    /** btoa */
    static btoa: (bin: string) => string;
    /** md5加密 */
    static md5: (str: string, pem?: string) => string;
    /** AES加密 */
    static aesEncrypt: (str: string, pem?: string) => any;
    /** AES解密 */
    static aesDecrypt: (str: string, pem?: string) => any;
    /** sm2 加密 */
    static sm2Encrypt: (params: any, publicKey: string) => string;
    /** sm2 解密 */
    static sm2Decrypt: (body: string, privateKey: string) => (Obj | undefined);
    /** 生成密钥对 */
    static sm2GenerateKeyPairHex: () => {
        privateKey: string;
        publicKey: string;
    };
}

/**
 * 时间转换函数
 * @param time 数据源
 * @param formatter 转换格式 默认为"YYYY-MM-DD HH:mm:ss"
 * @param defaultValue 展示值  默认为''
 */
declare function formatterTime(time: any, formatter?: string, defaultValue?: string): string;

/**
 * 获取数组
 * @param param 数据源
 * @param defaultValue 默认值
 */
declare function getArray<T = any>(param: any, defaultValue?: T[]): T[];

/** 对 Array.prototype.at 的兼容性处理 */
declare function getArrayAt<T>(param: T[], index?: number): T | undefined;

/**
 * 获取满足条件的数组单项
 * @param param 数据源
 * @param conditions 条件
 */
declare function getArrayItem<T extends Obj = Obj>(param: T[], conditions: Obj): T | undefined;

/**
 * 获取数组,数组去重（保留先匹配的值）
 * @param param 数据源
 * @param primaryKey 主键
 */
declare function getArrayNotRepeat<T>(param: T[], primaryKey?: string): T[];

/**
 * 获取布尔值
 * @param param 数据源
 * @param defaultValue 默认值
 */
declare function getBoolean(param: any, defaultValue?: boolean): boolean;

/**
 * 获取相似布尔值
 * @param param 数据源
 * @param defaultValue 默认值
 */
declare function getBooleanLike(param: any, defaultValue?: boolean): boolean;

/**
 * 获取对象数组的差异
 * @param newDataSource 新数据
 * @param oldDataSource 旧数据
 * @param options?.primaryKey    比对的唯一主键-默认为id字段
 * @param options?.isEqual       自定义比对函数-默认为全字段比对
 */
declare function getComputedDiff<T extends Obj = Obj>(param: DiffParam<T>): Promise<DiffReturn<T>>;

/** 获取当前时间戳 */
declare function getCurrentTime(): number;

/** 转换为dayjs时间 */
declare function getDayjs(param: any): default_2.Dayjs;

/** 获取当前时间 dayjs */
declare function getDayNow(): default_2.Dayjs;

/**
 * 获取环境变量
 * @param key 键名
 */
declare function getEnv<T>(key: string): T | undefined;

/**
 * 获取环境变量
 * @param key 键名
 * @param defaultValue 默认值
 */
declare function getEnv<T>(key: string, defaultValue?: T): T;

/**
 * 获取方法
 * @param param 数据源
 * @param defaultValue 默认值
 */
declare function getFunction(param: any, defaultValue?: Function): Function;

/**
 * 获取JSON数据
 * @param data 数据源
 */
declare function getJSONparse<T extends Obj = Obj>(data: any): T | undefined;

/**
 * 获取JSON数据
 * @param data 数据源
 * @param defaultValue 默认返回值
 */
declare function getJSONparse<T extends Obj = Obj>(data: any, defaultValue?: T): T;

/**
 * 将对象数组转换为Map （自动去重，保留先匹配的值）
 * @param param 对象数组
 * @param primaryKey 主键
 */
declare function getMapWithArray<T extends Obj = Obj>(param: T[], primaryKey?: string): Map<Id, T>;

/**
 * 将对象转换为Map
 * @param param 对象
 * @param primaryKey 主键
 */
declare function getMapWithObject(param: Obj): Map<any, any>;

/**
 * 获取数字
 * @param param 数据源
 * @param defaultValue 默认值
 */
declare function getNumber(param: any, defaultValue?: number): number;

/**
 * 数字小数位转换
 * @param param 数据源
 * @param fixed 转换位数
 */
declare function getNumberToFixed(param: any, fixed?: number): string;

/**
 * 千分位序列化
 * @param num 数据源
 * @param separator 分隔符
 * @returns
 */
declare function getNumbertoThousands(num?: number, separator?: string): string;

/**
 * 获取对象
 * @param param 数据源
 * @param defaultValue 默认值
 */
declare function getObject(param: any, defaultValue?: Obj): Obj;

/**
 * 获取对象,过滤掉对象中的空属性
 * @param param 数据源
 */
declare function getObjectFilterEmptyAttr(param: Obj): Obj;

/**
 * 获取对象,排除key
 * @param param 数据源
 * @param key 排除的key
 */
declare function getObjectFilterKey(source: Obj, key: string | string[]): Obj;

/**
 * 获取安全的返回值
 * @param valFunc 获取值的函数
 */
declare function getSafeValue<T = any>(valFunc: () => T): T | undefined;

/**
 * 获取安全的返回值
 * @param valFunc 获取值的函数
 * @param defaultValue 默认值
 */
declare function getSafeValue<T = any>(valFunc: () => T, defaultValue?: T): T;

/**
 * 获取search参数
 * @param key 获取的参数
 */
declare function getSearchParam<T = string>(key: string): T | undefined;

/**
 * 获取search参数
 * @param key 获取的参数
 * @param defaultValue 默认返回值
 */
declare function getSearchParam<T = string>(key: string, defaultValue?: T): T;

/**
 * 获取字符串
 * @param param 数据源
 * @param defaultValue 默认值
 */
declare function getString(param: any, defaultValue?: string): string;

/** 对 String.prototype.at 的兼容性处理 */
declare function getStringAt(param: string, index?: number): string | undefined;

/** 获取uuid */
declare function getUuid(): string;

/**
 * 获取一个立即执行的webworker执行器
 * @param executiveFunc 需要执行的函数（为避免计算错误，需要传递纯函数）
 */
declare function getWebWorker<Params extends any[] = any[], Return extends any = any>(executiveFunc: (..._args: Params) => Return): (..._args: Params) => Promise<Return>;

/** [ env ] 是否是安卓环境 */
declare function isAndroid(): boolean;

/** 是否时数组 */
declare function isArray(param: any): param is any[];

/** 是否是 BigInt */
declare function isBigInt(param: any): param is symbol;

/** 是否是布尔 */
declare function isBoolean(param: any): param is boolean;

/** 是否是合法 Date */
declare function isDate(param: any): param is Date;

/** 是否是 dayjs */
declare function isDayjs(param: any): param is Dayjs;

/** [ env ] 是否为开发环境 */
declare function isDev(): boolean;

/** 是否是空数组 */
declare function isEmptyArray(param: any): boolean;

/** 是否是空对象 */
declare function isEmptyObject(param: any): param is Object;

/** 两参数是否相等 */
declare function isEqual(paramA: any, paramB: any): boolean;

/** 参数是否存在 */
declare function isExist<T = any>(param: T): param is NonNullable<T>;

/** 是否是函数 */
declare function isFunction(param: any): param is Function;

/** [ env ] 是否是HarmonyOS环境  */
declare function isHarmony(): boolean;

/** [ env ] 是否是IOS环境  */
declare function isIOS(): boolean;

/** 是否是非空数组 */
declare function isNotEmptyArray(param: any): boolean;

/** 是否是非空对象 */
declare function isNotEmptyObject(param: any): param is Object;

/** 是否是非空字符串 */
declare function isNotEmptyString(param: any): param is string;

/** 参数是否不存在 */
declare function isNotExist(param: any): param is (undefined | null);

/** 是否是数字 */
declare function isNumber(param: any): param is number;

/** 是否是Object对象 */
declare function isObject(param: any): param is Object;

/** [ env ] 是否为生产环境 */
declare function isProd(): boolean;

/** 是否是字符串 */
declare function isString(param: any): param is string;

/** 是否是 Symbol */
declare function isSymbol(param: any): param is symbol;

/** [ env ] 是否为测试环境 */
declare function isTest(): boolean;

/** 是否是正整数 */
declare function isUpInteger(param: any): param is number;

/**
 * 动态加载脚本
 * @param url 脚本地址
 */
declare function loadScript(url: string): Promise<Event>;

/** 事件发布订阅器 */
export declare const Observed: {
    store: Map<string, Map<any, boolean>>;
    on<T>(type: string, fn: (e: T) => void, once?: boolean): void;
    off(type: string, fn?: Function): void;
    un: (type: string, fn?: Function) => void;
    emit<T>(type: string, data: T): void;
};

/**
 * 事件发布订阅器
 */
export declare const observed: Observed_2;

declare class Observed_2 {
    static instance: Observed_2;
    store: Map<string, Map<any, boolean>>;
    constructor();
    /**
     * 订阅
     * @param type 事件类型
     * @param fn 订阅函数
     * @param once 是否只执行一次,默认可多次执行
     */
    on<T>(type: string, fn: (e: T) => void, once?: boolean): void;
    /**
     * 取消订阅
     * @param type 事件类型
     * @param fn 订阅函数,若不传,则清空此类型的所有订阅函数
     */
    off(type: string, fn?: Function): void;
    /** 取消订阅 */
    un: (type: string, fn?: Function) => void;
    /**
     * 发布
     * @param type 事件类型 ObservedEventType
     * @param data 传递的数据
     */
    emit<T>(type: string, data: T): void;
}

/**
 * 动态并发
 * @description 用于处理大数组的数据处理，将密集操作拉平成为链式操作,（无法保证执行的顺序）
 * @param dataSource 并发数据源
 * @param render 数据源单项的执行函数 *** 请确保 resolve, reject 两个状态函数在render中至少需要调用一个 ***
 * @param options 配置项 concurrency 最大并发数(默认为 DEFAULT_CONCURRENCY = 20)
 */
declare function occurPromise<T extends Obj = Obj>(dataSource: T[], render: (item: T, resolve: Function, reject: Function) => void, options?: {
    concurrency?: number;
}): void;

/**
 * 设置属性值
 * @param source 设置源
 * @param values 设置值
 */
declare function setAttr(source?: Obj, values?: Obj): void;

/** Sse 客户端连接工具 */
export declare const SSE: typeof sse;

/** Sse 客户端连接工具 */
export declare class sse {
    static instance: sse | null;
    private client;
    private options;
    private eventStore;
    constructor(uri: string, options: SseOptions);
    /** 初始化 */
    private initClicent;
    /** 注册事件 */
    on: <T>(type: string, event: (data: T) => void, once?: boolean) => undefined;
    /** 取消事件注册 */
    off: (type: string, event: Function) => undefined;
    /** 清空某个类型的事件注册 */
    clear: (type: string) => undefined;
    /** 清空所有的事件注册 */
    clearAll: () => undefined;
    /** 销毁 */
    destory: () => undefined;
}

declare interface SseOptions {
    /** 认证auth信息 */
    token: string;
    /** 信道ID */
    channelId?: string;
    /** 连接关闭回调 */
    close?: Function;
    /** 连接成功回调 */
    open?: (client: sse) => void;
    /** 连接错误回调 */
    error?: Function;
}

/** 本地化存储的功能封装 */
export declare abstract class storage {
    private constructor();
    private static currentStore;
    /** 获取源 */
    private static _getStore;
    /** 获取解密后的数据 */
    private static _getDeVal;
    /** 设置源 */
    static setStore: (type: StoreType) => void;
    /** 是否存在 */
    static has: (key: string) => boolean;
    static get<T = string>(key: string): T | undefined;
    static get<T = string>(key: string, defaultValue?: T): T;
    /**
     * 存数据
     * @param key key <不允许中文>
     * @param value value
     * @param expire 过期时间 <'never' | number> 单位为分钟
     * @returns
     */
    static set: (key: string, value: any, expire?: "never" | number) => any;
    /** 批量存数据
     * { 'xxx':{expire:'xx'} } 存在 expire 即可设置超期时间
     */
    static sets: (values: Obj) => void;
    /** 删除数据*/
    static remove: (key: string) => void;
    /** 批量删除数据 */
    static removes: (keys: string[]) => void;
    /** 清空本地存储 */
    static clear: (all?: boolean) => void;
    /** 当前存储库的大小(b) */
    static size: () => number;
}

/** 本地化存储的功能封装 */
declare const Storage_2: typeof storage;
export { Storage_2 as Storage }

declare type StoreType = 'localStorage' | 'sessionStorage';

/** 工具函数 */
export declare const Utils: {
    isDev: isDev;
    isTest: isTest;
    isProd: isProd;
    isAndroid: isAndroid;
    isIOS: isIOS;
    isHarmony: isHarmony;
    isObject: isObject;
    isEmptyObject: isEmptyObject;
    isNotEmptyObject: isNotEmptyObject;
    isFunction: isFunction;
    isSymbol: isSymbol;
    isBigInt: isBigInt;
    isNumber: isNumber;
    isUpInteger: isUpInteger;
    isBoolean: isBoolean;
    isString: isString;
    isNotEmptyString: isNotEmptyString;
    isArray: isArray;
    isEmptyArray: isEmptyArray;
    isNotEmptyArray: isNotEmptyArray;
    isExist: isExist;
    isNotExist: isNotExist;
    isEqual: isEqual;
    isDate: isDate;
    isDayjs: isDayjs;
    getEnv: getEnv;
    getUuid: getUuid;
    getArray: getArray;
    getArrayAt: getArrayAt;
    getArrayItem: getArrayItem;
    getArrayNotRepeat: getArrayNotRepeat;
    getMapWithArray: getMapWithArray;
    getMapWithObject: getMapWithObject;
    getObject: getObject;
    getObjectFilterKey: getObjectFilterKey;
    getObjectFilterEmptyAttr: getObjectFilterEmptyAttr;
    getFunction: getFunction;
    getBoolean: getBoolean;
    getBooleanLike: getBooleanLike;
    getString: getString;
    getStringAt: getStringAt;
    getNumber: getNumber;
    getNumberToFixed: getNumberToFixed;
    getNumbertoThousands: getNumbertoThousands;
    getComputedDiff: getComputedDiff;
    getWebWorker: getWebWorker;
    getDayjs: getDayjs;
    getDayNow: getDayNow;
    getCurrentTime: getCurrentTime;
    getSearchParam: getSearchParam;
    getJSONparse: getJSONparse;
    getSafeValue: getSafeValue;
    setAttr: setAttr;
    formatter: string;
    formatterTime: formatterTime;
    emptyFunc: emptyFunc;
    deepClone: deepClone;
    writeToClipboard: writeToClipboard;
    loadScript: loadScript;
    occurPromise: occurPromise;
};

export declare const utils: {
    isDev: typeof isDev;
    isTest: typeof isTest;
    isProd: typeof isProd;
    isAndroid: typeof isAndroid;
    isIOS: typeof isIOS;
    isHarmony: typeof isHarmony;
    isObject: typeof isObject;
    isEmptyObject: typeof isEmptyObject;
    isNotEmptyObject: typeof isNotEmptyObject;
    isFunction: typeof isFunction;
    isSymbol: typeof isSymbol;
    isBigInt: typeof isBigInt;
    isNumber: typeof isNumber;
    isUpInteger: typeof isUpInteger;
    isBoolean: typeof isBoolean;
    isString: typeof isString;
    isNotEmptyString: typeof isNotEmptyString;
    isArray: typeof isArray;
    isEmptyArray: typeof isEmptyArray;
    isNotEmptyArray: typeof isNotEmptyArray;
    isExist: typeof isExist;
    isNotExist: typeof isNotExist;
    isEqual: typeof isEqual;
    isDate: typeof isDate;
    isDayjs: typeof isDayjs;
    getEnv: typeof getEnv;
    getUuid: typeof getUuid;
    getArray: typeof getArray;
    getArrayAt: typeof getArrayAt;
    getArrayItem: typeof getArrayItem;
    getArrayNotRepeat: typeof getArrayNotRepeat;
    getMapWithArray: typeof getMapWithArray;
    getMapWithObject: typeof getMapWithObject;
    getObject: typeof getObject;
    getObjectFilterKey: typeof getObjectFilterKey;
    getObjectFilterEmptyAttr: typeof getObjectFilterEmptyAttr;
    getFunction: typeof getFunction;
    getBoolean: typeof getBoolean;
    getBooleanLike: typeof getBooleanLike;
    getString: typeof getString;
    getStringAt: typeof getStringAt;
    getNumber: typeof getNumber;
    getNumberToFixed: typeof getNumberToFixed;
    getNumbertoThousands: typeof getNumbertoThousands;
    getComputedDiff: typeof getComputedDiff;
    getWebWorker: typeof getWebWorker;
    getDayjs: typeof getDayjs;
    getDayNow: typeof getDayNow;
    getCurrentTime: typeof getCurrentTime;
    getSearchParam: typeof getSearchParam;
    getJSONparse: typeof getJSONparse;
    getSafeValue: typeof getSafeValue;
    setAttr: typeof setAttr;
    formatter: string;
    formatterTime: typeof formatterTime;
    emptyFunc: typeof emptyFunc;
    deepClone: typeof deepClone;
    writeToClipboard: typeof writeToClipboard;
    loadScript: typeof loadScript;
    occurPromise: typeof occurPromise;
};

/** 版本信息 */
export declare const Version: typeof version;

/** 版本信息 */
export declare class version {
    private contentColor;
    private titleColor;
    private versionKey;
    constructor(consoleClear?: boolean);
    private initColor;
    private mark;
    /** 检查是否有更新 */
    checkUpdate: () => Promise<void>;
}

/**
 * 写入剪切板
 * @param text 写入内容
 */
declare function writeToClipboard(text: string): Promise<boolean>;

/** Socket 客户端连接工具 */
export declare const WS: typeof ws;

/** Socket 客户端连接工具 */
export declare class ws {
    static instance: ws | null;
    private client;
    private options;
    private eventStore;
    constructor(uri: string, options: WSOptions);
    /** 初始化 */
    private initClicent;
    /** 注册事件 */
    on: <T>(type: string, event: (data: T) => void, once?: boolean) => undefined;
    /** 取消事件注册 */
    off: (type: string, event: Function) => undefined;
    /** 清空某个类型的事件注册 */
    clear: (type: string) => undefined;
    /** 清空所有的事件注册 */
    clearAll: () => undefined;
    /** 销毁 */
    destory: () => undefined;
    /** 发送消息 */
    send: (type: string, message: any) => undefined;
}

declare interface WSOptions {
    /** 认证auth信息 */
    token: string;
    /** 其他参数 */
    query?: Obj;
    /** 路径 */
    path?: string;
    /** 连接关闭回调 */
    close?: Function;
    /** 连接成功回调 */
    open?: (client: ws) => void;
    /** 连接错误回调 */
    error?: Function;
    /** 连接断开 */
    disconnect?: Function;
}

export { }
