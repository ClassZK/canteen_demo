/** 版本信息 */
declare class Version {
    private contentColor;
    private titleColor;
    private versionKey;
    constructor(consoleClear?: boolean);
    private initColor;
    private mark;
    /** 检查是否有更新 */
    checkUpdate: () => Promise<void>;
}
export default Version;

export { }
