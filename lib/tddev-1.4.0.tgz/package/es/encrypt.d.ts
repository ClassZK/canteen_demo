/** 加解密工具 */
declare abstract class Encrypt {
    private constructor();
    /** atob */
    static atob: (asc: string) => string;
    /** btoa */
    static btoa: (bin: string) => string;
    /** md5加密 */
    static md5: (str: string, pem?: string) => string;
    /** AES加密 */
    static aesEncrypt: (str: string, pem?: string) => any;
    /** AES解密 */
    static aesDecrypt: (str: string, pem?: string) => any;
    /** sm2 加密 */
    static sm2Encrypt: (params: any, publicKey: string) => string;
    /** sm2 解密 */
    static sm2Decrypt: (body: string, privateKey: string) => (Obj | undefined);
    /** 生成密钥对 */
    static sm2GenerateKeyPairHex: () => {
        privateKey: string;
        publicKey: string;
    };
}
export default Encrypt;

export { }
