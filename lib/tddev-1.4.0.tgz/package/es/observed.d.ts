/** 发布函数 */
export declare const emit: <T>(type: string, data: T) => void;

declare class Observed {
    static instance: Observed;
    store: Map<string, Map<any, boolean>>;
    constructor();
    /**
     * 订阅
     * @param type 事件类型
     * @param fn 订阅函数
     * @param once 是否只执行一次,默认可多次执行
     */
    on<T>(type: string, fn: (e: T) => void, once?: boolean): void;
    /**
     * 取消订阅
     * @param type 事件类型
     * @param fn 订阅函数,若不传,则清空此类型的所有订阅函数
     */
    off(type: string, fn?: Function): void;
    /** 取消订阅 */
    un: (type: string, fn?: Function) => void;
    /**
     * 发布
     * @param type 事件类型 ObservedEventType
     * @param data 传递的数据
     */
    emit<T>(type: string, data: T): void;
}

/**
 * 事件发布订阅器
 */
declare const ObservedInstance: Observed;
export default ObservedInstance;

/** 取消订阅函数 */
export declare const off: (type: string, fn?: Function) => void;

/** 订阅函数 */
export declare const on: <T>(type: string, fn: (e: T) => void, once?: boolean) => void;

/** 取消订阅函数 */
export declare const un: (type: string, fn?: Function) => void;

/** 事件发布hook */
export declare const useEventEmitter: <T>(type: string, fn: (e: T) => void) => void;

export { }
