import { Dayjs } from 'dayjs';
import { default as default_2 } from 'dayjs';

/** 深拷贝 */
export declare function deepClone<T>(obj: T, __clonedObjects__?: WeakMap<WeakKey, any>): T;

declare const _default: {
    isDev: typeof isDev;
    isTest: typeof isTest;
    isProd: typeof isProd;
    isAndroid: typeof isAndroid;
    isIOS: typeof isIOS;
    isHarmony: typeof isHarmony;
    isObject: typeof isObject;
    isEmptyObject: typeof isEmptyObject;
    isNotEmptyObject: typeof isNotEmptyObject;
    isFunction: typeof isFunction;
    isSymbol: typeof isSymbol;
    isBigInt: typeof isBigInt;
    isNumber: typeof isNumber;
    isUpInteger: typeof isUpInteger;
    isBoolean: typeof isBoolean;
    isString: typeof isString;
    isNotEmptyString: typeof isNotEmptyString;
    isArray: typeof isArray;
    isEmptyArray: typeof isEmptyArray;
    isNotEmptyArray: typeof isNotEmptyArray;
    isExist: typeof isExist;
    isNotExist: typeof isNotExist;
    isEqual: typeof isEqual;
    isDate: typeof isDate;
    isDayjs: typeof isDayjs;
    getEnv: typeof getEnv;
    getUuid: typeof getUuid;
    getArray: typeof getArray;
    getArrayAt: typeof getArrayAt;
    getArrayItem: typeof getArrayItem;
    getArrayNotRepeat: typeof getArrayNotRepeat;
    getMapWithArray: typeof getMapWithArray;
    getMapWithObject: typeof getMapWithObject;
    getObject: typeof getObject;
    getObjectFilterKey: typeof getObjectFilterKey;
    getObjectFilterEmptyAttr: typeof getObjectFilterEmptyAttr;
    getFunction: typeof getFunction;
    getBoolean: typeof getBoolean;
    getBooleanLike: typeof getBooleanLike;
    getString: typeof getString;
    getStringAt: typeof getStringAt;
    getNumber: typeof getNumber;
    getNumberToFixed: typeof getNumberToFixed;
    getNumbertoThousands: typeof getNumbertoThousands;
    getComputedDiff: typeof getComputedDiff;
    getWebWorker: typeof getWebWorker;
    getDayjs: typeof getDayjs;
    getDayNow: typeof getDayNow;
    getCurrentTime: typeof getCurrentTime;
    getSearchParam: typeof getSearchParam;
    getJSONparse: typeof getJSONparse;
    getSafeValue: typeof getSafeValue;
    setAttr: typeof setAttr;
    formatter: string;
    formatterTime: typeof formatterTime;
    emptyFunc: typeof emptyFunc;
    deepClone: typeof deepClone;
    writeToClipboard: typeof writeToClipboard;
    loadScript: typeof loadScript;
    occurPromise: typeof occurPromise;
};
export default _default;

declare type DiffParam<T> = {
    /** 新数据 */
    newDataSource: T[];
    /** 旧数据 */
    oldDataSource: T[];
    options?: {
        /** 比对的主键-默认为id字段 */
        primaryKey?: string;
        /** 自定义比对函数-默认为全字段匹配 */
        isEqual?: (sourceOne: T, sourceTow: T) => boolean;
    };
};

declare type DiffReturn<T> = {
    /** 新增的项 */
    createItems: T[];
    /** 更新的项 */
    updateItems: T[];
    /** 被更新的项 */
    updatedItems: T[];
    /** 删除的项 */
    deleteItems: T[];
    /** 新增的id */
    createIds: Id[];
    /** 更新的id */
    updateIds: Id[];
    /** 删除的id */
    deleteIds: Id[];
};

/** 空方法 */
export declare function emptyFunc(): void;

/** 获取默认时间转换格式 */
export declare const formatter = "YYYY-MM-DD HH:mm:ss";

/**
 * 时间转换函数
 * @param time 数据源
 * @param formatter 转换格式 默认为"YYYY-MM-DD HH:mm:ss"
 * @param defaultValue 展示值  默认为''
 */
export declare function formatterTime(time: any, formatter?: string, defaultValue?: string): string;

/**
 * 获取数组
 * @param param 数据源
 * @param defaultValue 默认值
 */
export declare function getArray<T = any>(param: any, defaultValue?: T[]): T[];

/** 对 Array.prototype.at 的兼容性处理 */
export declare function getArrayAt<T>(param: T[], index?: number): T | undefined;

/**
 * 获取满足条件的数组单项
 * @param param 数据源
 * @param conditions 条件
 */
export declare function getArrayItem<T extends Obj = Obj>(param: T[], conditions: Obj): T | undefined;

/**
 * 获取数组,数组去重（保留先匹配的值）
 * @param param 数据源
 * @param primaryKey 主键
 */
export declare function getArrayNotRepeat<T>(param: T[], primaryKey?: string): T[];

/**
 * 获取布尔值
 * @param param 数据源
 * @param defaultValue 默认值
 */
export declare function getBoolean(param: any, defaultValue?: boolean): boolean;

/**
 * 获取相似布尔值
 * @param param 数据源
 * @param defaultValue 默认值
 */
export declare function getBooleanLike(param: any, defaultValue?: boolean): boolean;

/**
 * 获取对象数组的差异
 * @param newDataSource 新数据
 * @param oldDataSource 旧数据
 * @param options?.primaryKey    比对的唯一主键-默认为id字段
 * @param options?.isEqual       自定义比对函数-默认为全字段比对
 */
export declare function getComputedDiff<T extends Obj = Obj>(param: DiffParam<T>): Promise<DiffReturn<T>>;

/** 获取当前时间戳 */
export declare function getCurrentTime(): number;

/** 转换为dayjs时间 */
export declare function getDayjs(param: any): default_2.Dayjs;

/** 获取当前时间 dayjs */
export declare function getDayNow(): default_2.Dayjs;

/**
 * 获取环境变量
 * @param key 键名
 */
export declare function getEnv<T>(key: string): T | undefined;

/**
 * 获取环境变量
 * @param key 键名
 * @param defaultValue 默认值
 */
export declare function getEnv<T>(key: string, defaultValue?: T): T;

/**
 * 获取方法
 * @param param 数据源
 * @param defaultValue 默认值
 */
export declare function getFunction(param: any, defaultValue?: Function): Function;

/**
 * 获取JSON数据
 * @param data 数据源
 */
export declare function getJSONparse<T extends Obj = Obj>(data: any): T | undefined;

/**
 * 获取JSON数据
 * @param data 数据源
 * @param defaultValue 默认返回值
 */
export declare function getJSONparse<T extends Obj = Obj>(data: any, defaultValue?: T): T;

/**
 * 将对象数组转换为Map （自动去重，保留先匹配的值）
 * @param param 对象数组
 * @param primaryKey 主键
 */
export declare function getMapWithArray<T extends Obj = Obj>(param: T[], primaryKey?: string): Map<Id, T>;

/**
 * 将对象转换为Map
 * @param param 对象
 * @param primaryKey 主键
 */
export declare function getMapWithObject(param: Obj): Map<any, any>;

/**
 * 获取数字
 * @param param 数据源
 * @param defaultValue 默认值
 */
export declare function getNumber(param: any, defaultValue?: number): number;

/**
 * 数字小数位转换
 * @param param 数据源
 * @param fixed 转换位数
 */
export declare function getNumberToFixed(param: any, fixed?: number): string;

/**
 * 千分位序列化
 * @param num 数据源
 * @param separator 分隔符
 * @returns
 */
export declare function getNumbertoThousands(num?: number, separator?: string): string;

/**
 * 获取对象
 * @param param 数据源
 * @param defaultValue 默认值
 */
export declare function getObject(param: any, defaultValue?: Obj): Obj;

/**
 * 获取对象,过滤掉对象中的空属性
 * @param param 数据源
 */
export declare function getObjectFilterEmptyAttr(param: Obj): Obj;

/**
 * 获取对象,排除key
 * @param param 数据源
 * @param key 排除的key
 */
export declare function getObjectFilterKey(source: Obj, key: string | string[]): Obj;

/**
 * 获取安全的返回值
 * @param valFunc 获取值的函数
 */
export declare function getSafeValue<T = any>(valFunc: () => T): T | undefined;

/**
 * 获取安全的返回值
 * @param valFunc 获取值的函数
 * @param defaultValue 默认值
 */
export declare function getSafeValue<T = any>(valFunc: () => T, defaultValue?: T): T;

/**
 * 获取search参数
 * @param key 获取的参数
 */
export declare function getSearchParam<T = string>(key: string): T | undefined;

/**
 * 获取search参数
 * @param key 获取的参数
 * @param defaultValue 默认返回值
 */
export declare function getSearchParam<T = string>(key: string, defaultValue?: T): T;

/**
 * 获取字符串
 * @param param 数据源
 * @param defaultValue 默认值
 */
export declare function getString(param: any, defaultValue?: string): string;

/** 对 String.prototype.at 的兼容性处理 */
export declare function getStringAt(param: string, index?: number): string | undefined;

/** 获取uuid */
export declare function getUuid(): string;

/**
 * 获取一个立即执行的webworker执行器
 * @param executiveFunc 需要执行的函数（为避免计算错误，需要传递纯函数）
 */
export declare function getWebWorker<Params extends any[] = any[], Return extends any = any>(executiveFunc: (..._args: Params) => Return): (..._args: Params) => Promise<Return>;

/** [ env ] 是否是安卓环境 */
export declare function isAndroid(): boolean;

/** 是否时数组 */
export declare function isArray(param: any): param is any[];

/** 是否是 BigInt */
export declare function isBigInt(param: any): param is symbol;

/** 是否是布尔 */
export declare function isBoolean(param: any): param is boolean;

/** 是否是合法 Date */
export declare function isDate(param: any): param is Date;

/** 是否是 dayjs */
export declare function isDayjs(param: any): param is Dayjs;

/** [ env ] 是否为开发环境 */
export declare function isDev(): boolean;

/** 是否是空数组 */
export declare function isEmptyArray(param: any): boolean;

/** 是否是空对象 */
export declare function isEmptyObject(param: any): param is Object;

/** 两参数是否相等 */
export declare function isEqual(paramA: any, paramB: any): boolean;

/** 参数是否存在 */
export declare function isExist<T = any>(param: T): param is NonNullable<T>;

/** 是否是函数 */
export declare function isFunction(param: any): param is Function;

/** [ env ] 是否是HarmonyOS环境  */
export declare function isHarmony(): boolean;

/** [ env ] 是否是IOS环境  */
export declare function isIOS(): boolean;

/** 是否是非空数组 */
export declare function isNotEmptyArray(param: any): boolean;

/** 是否是非空对象 */
export declare function isNotEmptyObject(param: any): param is Object;

/** 是否是非空字符串 */
export declare function isNotEmptyString(param: any): param is string;

/** 参数是否不存在 */
export declare function isNotExist(param: any): param is (undefined | null);

/** 是否是数字 */
export declare function isNumber(param: any): param is number;

/** 是否是Object对象 */
export declare function isObject(param: any): param is Object;

/** [ env ] 是否为生产环境 */
export declare function isProd(): boolean;

/** 是否是字符串 */
export declare function isString(param: any): param is string;

/** 是否是 Symbol */
export declare function isSymbol(param: any): param is symbol;

/** [ env ] 是否为测试环境 */
export declare function isTest(): boolean;

/** 是否是正整数 */
export declare function isUpInteger(param: any): param is number;

/**
 * 动态加载脚本
 * @param url 脚本地址
 */
export declare function loadScript(url: string): Promise<Event>;

/**
 * 动态并发
 * @description 用于处理大数组的数据处理，将密集操作拉平成为链式操作,（无法保证执行的顺序）
 * @param dataSource 并发数据源
 * @param render 数据源单项的执行函数 *** 请确保 resolve, reject 两个状态函数在render中至少需要调用一个 ***
 * @param options 配置项 concurrency 最大并发数(默认为 DEFAULT_CONCURRENCY = 20)
 */
export declare function occurPromise<T extends Obj = Obj>(dataSource: T[], render: (item: T, resolve: Function, reject: Function) => void, options?: {
    concurrency?: number;
}): void;

/**
 * 设置属性值
 * @param source 设置源
 * @param values 设置值
 */
export declare function setAttr(source?: Obj, values?: Obj): void;

/**
 * 写入剪切板
 * @param text 写入内容
 */
export declare function writeToClipboard(text: string): Promise<boolean>;

export { }
