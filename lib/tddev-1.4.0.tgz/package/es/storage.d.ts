/** 本地化存储的功能封装 */
declare abstract class Storage_2 {
    private constructor();
    private static currentStore;
    /** 获取源 */
    private static _getStore;
    /** 获取解密后的数据 */
    private static _getDeVal;
    /** 设置源 */
    static setStore: (type: StoreType) => void;
    /** 是否存在 */
    static has: (key: string) => boolean;
    static get<T = string>(key: string): T | undefined;
    static get<T = string>(key: string, defaultValue?: T): T;
    /**
     * 存数据
     * @param key key <不允许中文>
     * @param value value
     * @param expire 过期时间 <'never' | number> 单位为分钟
     * @returns
     */
    static set: (key: string, value: any, expire?: "never" | number) => any;
    /** 批量存数据
     * { 'xxx':{expire:'xx'} } 存在 expire 即可设置超期时间
     */
    static sets: (values: Obj) => void;
    /** 删除数据*/
    static remove: (key: string) => void;
    /** 批量删除数据 */
    static removes: (keys: string[]) => void;
    /** 清空本地存储 */
    static clear: (all?: boolean) => void;
    /** 当前存储库的大小(b) */
    static size: () => number;
}
export default Storage_2;

declare type StoreType = 'localStorage' | 'sessionStorage';

export { }
