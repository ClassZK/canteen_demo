# DZCORE

**TDDEV-TEAM**

DZ-TEl软研前端工具库

# 更新日志
1、增加utils聚合导出方式，utils也可按需引入，减少打包体积  
2、Utils  
    新增 getStringAt 对 String.prototype.at 的兼容性处理 
    新增 getArrayAt  对 Array.prototype.at  的兼容性处理 